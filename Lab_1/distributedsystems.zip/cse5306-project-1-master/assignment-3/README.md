Synchronouse RPC
================


Project team members
--------------------



Requirements
------------

- Python >= 3.6
- NumPy


Usage
-----

First start the server in a terminal:

    $ python3 server.py

Then, in another terminal, run the client:

    $ python3 client.py
